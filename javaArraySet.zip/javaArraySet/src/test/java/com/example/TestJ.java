package com.example;

import org.junit.Test;
import static org.junit.Assert.assertEquals;
public class TestJ {
   @Test
   public void testAdd() {
      String str= "Junit is working fine";
      assertEquals("Junit is working fine",str);
   }

   @Test
   public void testDelete() {
      String str= "Junit is working fine";
      assertEquals("Junit is working fine",str);
   }

   
}
