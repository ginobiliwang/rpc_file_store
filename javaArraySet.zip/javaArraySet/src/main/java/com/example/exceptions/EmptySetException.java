package com.example.exceptions;

public class EmptySetException extends RuntimeException
{
    private static final long serialVersionUID = 1L;

    // -----------------------------------------------------------------
   //  Creates the exception.
   //-----------------------------------------------------------------
   public EmptySetException()
   {
      super ("The set is empty.");
   }

   //-----------------------------------------------------------------
   //  Creates the exception with the specified message.
   //-----------------------------------------------------------------
   public EmptySetException (String message)
   {
      super (message);
   }
}