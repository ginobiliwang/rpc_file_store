package setimp_test

import (
	"set/setimp"

	. "github.com/onsi/ginkgo"
	. "github.com/onsi/gomega"
)

var _ = Describe("Set", func() {

	var s *setimp.Set
	//var err error

	BeforeEach(func() {
		s = setimp.NewSet()
		By("Begin One Test")
	})

	AfterEach(func() {
		By("End One Test")
	})

	It("Test Add Function", func() {
		s.Add(1)
		s.Add(2)
		s.Add("3")
		Expect(s.Size()).To(Equal(3))
	})

	It("Test Remove Function", func() {
		s.Add(1)
		s.Add(2)
		s.Add("3")
		s.Remove("3")
		Expect(s.Size()).To(Equal(2))
	})

	It("Test IsEmpty Function", func() {
		Expect(s.IsEmpty()).To(Equal(true))
	})

	It("Test Contains Function", func() {
		Expect(s.Contains(2)).To(Equal(false))
	})
})
