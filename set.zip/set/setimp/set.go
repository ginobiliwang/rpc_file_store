package setimp

import (
	"fmt"
	"reflect"
)

//Set is ...
type Set struct {
	count int
	arr   []interface{}
}

//NewSet is ...
func NewSet() *Set {
	return &Set{0, make([]interface{}, 0)}
}

//Add is ...
func (s *Set) Add(v interface{}) {
	flag := s.Contains(v)
	if !flag {
		s.arr = append(s.arr, v)
		s.count++
	}
}

//AddAll is ...
func (s *Set) AddAll(v ...interface{}) {
	for _, value := range v {
		fmt.Println(value)
		s.Add(value)
	}
}

//Contains is ...
func (s *Set) Contains(v interface{}) bool {
	flag := false
	for _, value := range s.arr {
		if reflect.DeepEqual(value, v) {
			flag = true
		}
	}
	return flag
}

//Size is ...
func (s *Set) Size() int {
	//return len(s.arr)
	return s.count
}

//IsEmpty is ...
func (s *Set) IsEmpty() bool {
	flag := true
	if s.Size() > 0 {
		for _, value := range s.arr {
			if value != nil {
				flag = false
			}
		}
		return flag
	}
	return s.Size() == 0
}

//Remove is ...
func (s *Set) Remove(v interface{}) bool {
	flag := false
	for index, value := range s.arr {
		if reflect.DeepEqual(value, v) {
			flag = true
			s.arr[index] = nil
			s.count--
		}
	}
	return flag
}

//Clear is ...
func (s *Set) Clear() {
	copy(s.arr, make([]interface{}, len(s.arr)))
	s.count = 0
}

//ToArray is ...
func (s *Set) ToArray() *[]interface{} {
	return &s.arr
}
