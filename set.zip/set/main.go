package main

import (
	"fmt"
	"set/setimp"
)

func main() {
	s := setimp.NewSet()
	fmt.Println(s.IsEmpty())

	/*s.Add(1)
	  s.Add("2")
	  s.Add(1)
	  fmt.Println(s)

	  b:=s.Remove(2)
	  fmt.Println(b)
	  fmt.Println(s)*/

	s.AddAll("a", "b", "c")
	fmt.Println(s.IsEmpty())
	fmt.Println(s)

	arr := s.ToArray()
	fmt.Println(arr)

	s.Clear()
	fmt.Println(s.IsEmpty())
}
