package hashmap_test

import (
	. "github.com/onsi/ginkgo"
	. "github.com/onsi/gomega"

	. "hashmap"
)

var _ = Describe("Hashmap", func() {

	var hm *HashMap

	BeforeEach(func() {
		hm, _ = NewHashMap(2)
		By("Begin One Test")
	})

	AfterEach(func() {
		By("End One Test")
	})

	It("Test put and get", func() {
		hm.Set("1", 1)
		v1, _ := hm.Get("1")
		Expect(v1.Value).To(Equal(1))
		hm.Set("2", 2)
		v2, _ := hm.Get("2")
		Expect(v2.Value).To(Equal(2))
		hm.Set("3", 3)
		v3, _ := hm.Get("3")
		Expect(v3.Value).To(Equal(3))
		hm.Set("4", 4)
		v4, _ := hm.Get("4")
		Expect(v4.Value).To(Equal(4))
	})

	It("Test delete", func() {
		hm.Set("1", 1)
		v1, _ := hm.Get("1")
		Expect(v1.Value).To(Equal(1))
		v2, ret2 := hm.Delete("1")
		Expect(v2.Value).To(Equal(1))
		Expect(ret2).To(Equal(true))
		_, ret3 := hm.Get("1")
		Expect(ret3).To(Equal(false))
	})
})
