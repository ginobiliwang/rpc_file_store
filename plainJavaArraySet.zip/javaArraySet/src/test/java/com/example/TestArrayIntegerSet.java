package com.example;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

import com.example.exceptions.*;

import org.junit.Before;
import org.junit.BeforeClass;


public class TestArrayIntegerSet {
    private Set set;
    @BeforeClass
    public static void beforeClass() {
        //this method will be called one time when class init
        System.out.println("@BeforeClass");  
    }

    @Before
    public void setUp() {
        //this method will be called before each test function
       set = new Set(5);
    }

    @Test
    public void testIsEmpty () {
        assertEquals(true, set.isEmpty());
        set.add(1);
        assertEquals(false, set.isEmpty());
    }



    @Test
    public void testCreateArraySet() {
        assertEquals(true, set.isEmpty());
        assertEquals(0, set.size());
    }

    @Test(expected=NullPointerException.class)
    public void testAdd() {
        set.add(1);
        set.add(2);
        set.add(3);
        assertEquals(false, set.isEmpty());
        assertEquals(3, set.size());
        assertEquals(true, set.contains(1));
        assertEquals(false, set.contains(4));
        set.add(null);
    }

    @Test(expected=NullPointerException.class)
    public void testRemove() {
        set.add(1);
        set.add(2);
        set.add(3);
        assertEquals(3, set.size());
        set.remove(2);
        assertEquals(2, set.size());
        assertEquals(false, set.contains(2));
        set.remove(null);
    }

    @Test(expected=NullPointerException.class)
    public void testContainsNull() {
        set.contains(null);
    }

    @Test(expected=EmptySetException.class)
    public void testRemoveWithException()
    {
        set.add(1);
        set.add(2);
        set.remove(1);
        set.remove(2);
        set.remove(3);
    }

    @Test(expected = ElementNotFoundException.class)
    public void testElementNotFoundException()
    {
        set.add(1);
        set.remove(2);
        set.remove(null);
    }

    @Test
    public void testExpand()
    {
        set.add(1);
        set.add(2);
        set.add(3);
        set.add(4);
        set.add(5);
        assertEquals(5, set.size());
        set.add(6);
        assertEquals(6, set.size());
    }

    @Test
    public void testToArray()
    {
        set.add(1);
        set.add("1");
        set.add(2);
        set.add("2");
        assertEquals(4, set.size());
        Object out[] = set.toArray();
        assertEquals(4, out.length);
        assertEquals("2",out[3]);
    }
}