package com.example.exceptions;

public class ElementNotFoundException extends RuntimeException
{
    private static final long serialVersionUID = 1L;

    // -----------------------------------------------------------------
   //  Sets up this exception with an appropriate message.
   //-----------------------------------------------------------------
   public ElementNotFoundException (Object collection)
   {
      super ("The target element is not in this " + collection);
   }
}