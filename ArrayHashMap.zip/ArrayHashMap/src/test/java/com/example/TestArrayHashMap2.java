package com.example;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.BeforeClass;

public class TestArrayHashMap2 {
    private ArrayHashMap<String, String> testHash;

    @BeforeClass
    public static void beforeClass() {
        System.out.println("@BeforeClass");
    }

    @Before
    public void setUp() {
        testHash = new ArrayHashMap<String, String>(8);
    }

    @Test
    public void testIsEmpty () {
        assertEquals(true, testHash.isEmpty());
        testHash.put("first key", "first value");
        assertEquals(false, testHash.isEmpty());
    }

    @Test
    public void testPutAndGet() {
        testHash.put("first key", "first value");
        testHash.put("second key", "second value");
        testHash.put("third key", "third value");
        assertEquals(false, testHash.isEmpty());
        assertEquals("first value", testHash.get("first key"));
        assertEquals("second value", testHash.get("second key"));
        assertEquals("third value", testHash.get("third key"));
        testHash.put("another third key", "another third value");
        assertEquals("another third value", testHash.get("another third key"));
        assertEquals(null, testHash.get("fourth key"));

    }
}
