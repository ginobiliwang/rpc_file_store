package com.example;

import com.example.exception.ElementExitsException;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.BeforeClass;

public class TestArrayHashMap {

    private ArrayHashMap<Integer, String> testHash;

    @BeforeClass
    public static void beforeClass() {
        System.out.println("@BeforeClass");
    }

    @Before
    public void setUp() {
        testHash = new ArrayHashMap<Integer, String>(8);
    }

    @Test
    public void testIsEmpty () {
        assertEquals(true, testHash.isEmpty());
        testHash.put(1, "first string");
        assertEquals(false, testHash.isEmpty());
    }

    @Test
    public void testPutAndGet() {
        testHash.put(1, "first");
        testHash.put(2, "second");
        testHash.put(3, "third");
        assertEquals(false, testHash.isEmpty());
        assertEquals("first", testHash.get(1));
        assertEquals("second", testHash.get(2));
        assertEquals("third", testHash.get(3));
        //testHash.put(3, "another third");
        //assertEquals("another third", testHash.get(3));
        assertEquals(null, testHash.get(4));

    }


    @Test
    public void testPutAndGetWithSameKey() {
        testHash.put(1, "first");
        testHash.put(2, "second");
        testHash.put(3, "third");
        testHash.put(4, "four");
        testHash.put(5, "five");
        testHash.put(6, "six");
        testHash.put(7, "seven");
        testHash.put(8, "eight");
        testHash.put(9, "nine");
        testHash.put(10, "ten");
        testHash.put(11, "eleven");
        testHash.put(12, "twelve");

        assertEquals("first", testHash.get(1));
        assertEquals("nine", testHash.get(9));
        assertEquals("ten", testHash.get(10));
        assertEquals("eleven", testHash.get(11));
    }

    @Test
    public void testSize() {
        testHash.put(1, "first");
        testHash.put(2, "second");
        assertEquals(2, testHash.size());
    }


    @Test
    public void testRemove() {
        testHash.put(1, "first");
        testHash.put(2, "second");
        assertEquals(2, testHash.size());
        assertEquals("second", testHash.get(2));
        testHash.remove(2);
        assertEquals(1, testHash.size());
        assertEquals(null, testHash.get(2));
    }

    @Test
    public void testClear() {
        testHash.put(1, "first");
        testHash.put(2, "second");
        assertEquals(2, testHash.size());
        testHash.clear();
        assertEquals(0, testHash.size());
        assertEquals(true, testHash.isEmpty());
    }

    @Test
    public void testContainsKey() {
        testHash.put(1, "first");
        testHash.put(2, "second");
        assertEquals(true, testHash.containsKey(1));
        assertEquals(true, testHash.containsKey(2));
        assertEquals(false, testHash.containsKey(3));
    }

    @Test(expected = ElementExitsException.class)
    public void testElementExitsException() {
        testHash.put(1, "first");
        testHash.put(2, "second");
        testHash.put(2, "another second");
    }


}
