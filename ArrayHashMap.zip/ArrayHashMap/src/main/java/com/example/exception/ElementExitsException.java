package com.example.exception;

public class ElementExitsException extends RuntimeException
{
    private static final long serialVersionUID = 1L;

    // -----------------------------------------------------------------
    //  Sets up this exception with an appropriate message.
    //-----------------------------------------------------------------
    public ElementExitsException (Object o)
    {
        super ("The target element is not in this " + o);
    }
}