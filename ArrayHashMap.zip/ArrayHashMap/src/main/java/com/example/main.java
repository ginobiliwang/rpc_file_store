package com.example;

public class main {
    public static void main(String[] args) {
        ArrayHashMap<Integer, String> map = new ArrayHashMap<Integer, String>();
        map.put(1, "first");
        map.put(2, "second");
        map.put(3, "third");


        System.out.println(map.get(1));
        System.out.println(map.get(2));
        System.out.println(map.get(3));
        System.out.println(map.get(4));

        System.out.println(map.size());

        map.put(3, "another third");
        System.out.println(map.get(3));


    }
}
