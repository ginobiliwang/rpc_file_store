package com.example;

import com.example.exception.ElementExitsException;

public class ArrayHashMap<K, V> {
    private Entry[] table;
    static final int DEFAULT_INITIAL_CAPACITY = 128;
    private int size;
    private int count;

    public ArrayHashMap() {
        table = new Entry[DEFAULT_INITIAL_CAPACITY];
        size  = DEFAULT_INITIAL_CAPACITY;
        count = 0;
    }

    public ArrayHashMap(int initialCapacity) {
        table = new Entry[initialCapacity];
        size  = initialCapacity;
        count = 0;
    }

    public boolean isEmpty() {
        if(count != 0) {
            return false;
        }
        return true;
    }

    public int size() {
        return count;
    }

    static int indexFor(int h, int length) {
        return h % (length - 1);
    }

    public V get(Object key) {
        if(key == null) {
            return null;
        }
        int hash = Math.abs(key.hashCode());
        int index = indexFor(hash, table.length);
        for(Entry<K, V> e = table[index]; e != null; e = e.next) {
            Object k = e.key;
            if(Math.abs(e.key.hashCode()) == hash  &&  (k == key || key.equals(k))) {
                return e.value;
            }
        }
        return null;
    }

    public V put(K key, V value) throws ElementExitsException {
        if(key == null) {
            return null;
        }
        int hash = Math.abs(key.hashCode());
        int index = indexFor(hash, table.length);

        for (Entry<K, V> e=table[index]; e != null; e = e.next) {
            Object k = e.key;
            if(Math.abs(e.key.hashCode()) == hash && (k == key || key.equals(k))) {
                /*
                V oldValue = e.value;
                e.value = value;
                return oldValue;
                */
                throw new ElementExitsException(key);
            }
        }

        Entry<K, V> e = table[index];
        table[index] = new Entry<K, V>(key, value, e);
        count++;
        return null;
    }

    public V remove(K key)  {
        if(key == null) {
            return null;
        }
        int hash = Math.abs(key.hashCode());
        int index = indexFor(hash, table.length);

        Entry<K, V> pre = table[index];

        //1) we need to confirm if the element is the first one in the linked list
        Object k1 = pre.key;
        if (Math.abs(k1.hashCode()) == hash  && (k1 == key || key.equals(k1))) {
            V removedValue = pre.value;
            table[index] = pre.next; // null or not, we will give value to table[index]
            count--;
            return removedValue;
        }

        //2) if we have found that the Entry is not the first one in the linked list,
        //   we will need to search for it and remove it
        Entry<K, V> e = pre.next;
        for (; e != null; pre = e, e = pre.next) {
            Object k2 = e.key;
            if(Math.abs(k2.hashCode()) == hash && (k2 == key || key.equals(k2))) {
                V removedValue = e.value;
                pre.next = e.next;
                count--;
                return removedValue;
            }
        }

        return null;
    }

    public boolean clear() {
        for (int i=0; i<table.length; i++) {
            Entry<K, V> e = table[i];
            Entry<K, V> nex;
            while(e != null) {
                nex = e.next;
                remove(e.key);
                e = nex;
            }
        }
        return true;
    }

    public boolean containsKey(K key) {
        if(get(key) != null) {
            return true;
        } else {
            return false;
        }
    }

}
